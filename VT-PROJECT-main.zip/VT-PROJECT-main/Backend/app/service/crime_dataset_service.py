import pandas as pd
from math import radians, sin, cos, sqrt, atan2
from pathlib import Path

# -----------------------------
# Load Dataset Once
# -----------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = BASE_DIR / "datasets" / "raipur_crime_dataset_250.csv"

if DATA_FILE.exists():
    crime_df = pd.read_csv(DATA_FILE)
else:
    crime_df = pd.DataFrame(columns=[
        "crime_id",
        "crime_name",
        "crime_type",
        "severity",
        "crime_count",
        "latitude",
        "longitude",
        "locality",
    ])


# -----------------------------
# Haversine Distance
# -----------------------------

def calculate_distance(
    lat1,
    lon1,
    lat2,
    lon2
):

    R = 6371000

    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)

    a = (
        sin(dlat / 2) ** 2
        +
        cos(radians(lat1))
        *
        cos(radians(lat2))
        *
        sin(dlon / 2) ** 2
    )

    c = 2 * atan2(
        sqrt(a),
        sqrt(1 - a)
    )

    return R * c

def get_nearby_crimes(
    latitude: float,
    longitude: float,
    radius: int = 2000
):

    nearby = []

    if crime_df.empty:
        return nearby

    for _, crime in crime_df.iterrows():

        distance = calculate_distance(

            latitude,
            longitude,

            crime["latitude"],
            crime["longitude"]

        )

        if distance <= radius:

            nearby.append(

                {

                    "crime_id": crime["crime_id"],

                    "crime_name": crime["crime_name"],

                    "crime_type": crime["crime_type"],

                    "severity": crime["severity"],

                    "crime_count": crime["crime_count"],

                    "distance": round(distance, 2),

                    "locality": crime["locality"]

                }

            )

    return nearby

def calculate_crime_score(
    nearby_crimes
):

    score = 100

    crime_types = set()

    high_severity = 0

    for crime in nearby_crimes:

        crime_types.add(
            crime["crime_type"]
        )

        severity = crime["severity"]

        count = crime["crime_count"]

        if severity == "High":

            score -= 10

            high_severity += 1

        elif severity == "Medium":

            score -= 6

        else:

            score -= 3

        score -= min(
            count,
            5
        )

    score = max(
        score,
        0
    )

    return {

        "crime_score": score,

        "nearby_cases": len(
            nearby_crimes
        ),

        "high_severity_cases": high_severity,

        "common_crimes": list(
            crime_types
        )

    }